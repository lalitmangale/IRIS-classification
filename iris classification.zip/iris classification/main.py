from flask import Flask,render_template,request
import joblib

app = Flask(__name__)
model = joblib.load('model.pkl')
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/classify',methods=['POST','GET'])
def classify():
    if request.method == 'POST':
        sl = float(request.form.get('sepal_length'))
        sw = float(request.form.get('sepal_width'))
        pl = float(request.form.get('petal_length'))
        pw = float(request.form.get('petal_width'))
        predict = model.predict([[sl,sw,pl,pw]])
        img = ''
        if predict == 'Iris-setosa':
            print('enter')
            img = 'seatosa.jpg'
        elif predict == 'Iris-versicolor':
            img = 'versicolor.jpg'
        else:
            img = 'verginica.jpg'
        print(img)
    return render_template('index.html',classify=predict[0],display='block',img=img)

if __name__ == '__main__':
    app.run()
